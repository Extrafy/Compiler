package ir.types;

public interface Type {
    int getSize();
}
