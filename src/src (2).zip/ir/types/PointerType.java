package ir.types;

public class PointerType implements Type{
    private final Type targetType;

    public PointerType(Type targetType){
        this.targetType = targetType;
    }

    public Type getTargetType() {
        return targetType;
    }

    public boolean isString(){
        return targetType instanceof ArrayType && ((ArrayType) targetType).isCharArray();
    }

    public String toString(){
        return targetType.toString() + "*";
    }

    // 指针的大小为4 ???mips
    public int getSize() {
        return 4;
    }
}
