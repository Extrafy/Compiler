package frontend;

import error.Error;
import symbol.Symbol;
import utils.InputOutput;

import java.util.ArrayList;
import java.util.List;

public class SymbolPrinter {
    private static final SymbolPrinter instance = new SymbolPrinter();

    private List<Symbol> symbols = new ArrayList<>();

    public void printSymbols(){
        for (Symbol symbol : symbols) {
            InputOutput.write(symbol.toString());
        }
    }

    public static SymbolPrinter getInstance() {
        return instance;
    }

}
