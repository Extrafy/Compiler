package ir.types;

public interface Type {
}
