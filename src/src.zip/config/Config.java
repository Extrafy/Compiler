package config;

public class Config {
    public static String inputPath = "testfile.txt";
    public static String outputPath = "symbol.txt";
    public static String errorPath = "error.txt";
    public static boolean lexerFlag = false;
    public static boolean parserFlag = false;
    public static boolean symbolFlag = true;
    public static boolean errorFlag = false;
}
