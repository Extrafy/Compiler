package config;

public class Config {
    public static String inputPath = "testfile.txt";
    public static String outputPath = "lexer.txt";
    public static String errorPath = "error.txt";

    public static boolean errorFlag = false;
}
