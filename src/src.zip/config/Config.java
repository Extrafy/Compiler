package config;

public class Config {
    public static String inputPath = "testfile.txt";
    public static String outputPath = "lexer.txt";
    public static String errorPath = "error.txt";
    public static boolean lexerFlag = true;
    public static boolean parserFlag = false;
    public static boolean errorFlag = false;
}
