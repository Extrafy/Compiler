package symbol;

import java.util.HashMap;

public class SymbolTable {
    public HashMap<String, Symbol> symbolMap;
    public boolean isFunc;
    public FuncSymbol.FuncReturnType returnType;
    public int declLineNum;


    public SymbolTable(HashMap<String, Symbol> symbolMap, boolean isFunc, FuncSymbol.FuncReturnType returnType, int declLineNum) {
        this.symbolMap = symbolMap;
        this.isFunc = isFunc;
        this.returnType = returnType;
        this.declLineNum = declLineNum;
    }

    public HashMap<String, Symbol> getSymbolMap() {
        return symbolMap;
    }

    public boolean isFunc() {
        return isFunc;
    }

    public FuncSymbol.FuncReturnType getReturnType() {
        return returnType;
    }

    public int getDeclLineNum() {
        return declLineNum;
    }
}
