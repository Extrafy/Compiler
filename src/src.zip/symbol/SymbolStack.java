package symbol;

import AST.AST;
import error.HandleError;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SymbolStack {
    private static final SymbolStack instance = new SymbolStack();
    public static SymbolStack getInstance() {
        return instance;
    }
    private static int loopCount = 0;
    private static int curDeclLineNum = 1;
    private List<SymbolTable> symbolTables = new ArrayList<>();// 符号表栈 + 作用域

    private void addSymbolTable(boolean isFunc, FuncSymbol.FuncReturnType returnType, int declLineNum){
        symbolTables.add(new SymbolTable(new HashMap<>(), isFunc, returnType, declLineNum));
    }

    private void removeSymbolTable(){
        if (!symbolTables.isEmpty()){
            symbolTables.remove(symbolTables.size() - 1);
        }
        else{
            throw new RuntimeException("栈为空无法删除");
        }
    }

    private boolean isInCurrent(String ident){  // b:名字重定义
        if(!symbolTables.isEmpty()){
            return symbolTables.get(symbolTables.size() - 1).symbolMap.containsKey(ident);
        }
        else {
            throw new RuntimeException("栈为空无法获取");
        }
    }

    private boolean contains(String ident){  // c:未定义的名字
        for (int i = symbolTables.size() - 1; i >= 0; i --){
            if (symbolTables.get(i).symbolMap.containsKey(ident)){
                return true;
            }
        }
        return false;
    }

    private boolean isInFunc(){
        for (int i = symbolTables.size() - 1; i >= 0 ; i--){
            if (symbolTables.get(i).isFunc){
                return true;
            }
        }
        return false;
    }

    private FuncSymbol.FuncReturnType getReturnType(){
        for (int i = symbolTables.size() - 1; i>= 0; i--){
            if (symbolTables.get(i).isFunc){
                return symbolTables.get(i).returnType;
            }
        }
        return null;
    }

    private boolean isCurrentFunc() {
        return symbolTables.get(symbolTables.size() - 1).isFunc;
    }

    private FuncSymbol.FuncReturnType getCurrentFuncType() {
        return symbolTables.get(symbolTables.size() - 1).returnType;
    }

    private void put(String ident, Symbol symbol){
        symbolTables.get(symbolTables.size() - 1).symbolMap.put(ident, symbol);
    }

    private Symbol get(String ident){
        for (int i = symbolTables.size() - 1; i >= 0; i--){
            if (symbolTables.get(i).symbolMap.containsKey(ident)){
                return symbolTables.get(i).symbolMap.get(ident);
            }
        }
        return null;
    }
}
