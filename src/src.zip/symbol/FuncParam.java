package symbol;

public class FuncParam extends Symbol{
    private int dimension; // 0变量, 1数组


    public FuncParam(String name, SymbolType symbolType, int num, int dimension) {
        super(name, symbolType, num);
        this.dimension = dimension;
    }

    public int getDimension() {
        return dimension;
    }

    public String toString() {
        return "FuncParam{" +
                "name='" + getName() + '\'' +
                ", dimension=" + dimension +
                '}';
    }
}
